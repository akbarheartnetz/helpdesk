from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('tickets/', views.ticket_list, name='ticket_list'),
    path('tickets/create/', views.ticket_create, name='ticket_create'),
    path('tickets/<int:pk>/', views.ticket_detail, name='ticket_detail'),
    path('tickets/<int:pk>/update/', views.ticket_update, name='ticket_update'),
    path('tickets/<int:pk>/approve/', views.ticket_approve, name='ticket_approve'),
    path('tickets/<int:pk>/upload/', views.upload_attachment, name='upload_attachment'),
    
    # Master Data URLs
    path('master/category/', views.master_category_list, name='master_category_list'),
    path('master/category/create/', views.master_category_create, name='master_category_create'),
    path('master/category/<int:pk>/update/', views.master_category_update, name='master_category_update'),
    path('master/category/<int:pk>/delete/', views.master_category_delete, name='master_category_delete'),
    
    path('master/user/', views.master_user_list, name='master_user_list'),
    path('master/user/create/', views.master_user_create, name='master_user_create'),
    path('master/user/<int:pk>/update/', views.master_user_update, name='master_user_update'),
    path('master/user/<int:pk>/delete/', views.master_user_delete, name='master_user_delete'),
    
    # Reports URL
    path('reports/', views.reports_view, name='reports'),
]