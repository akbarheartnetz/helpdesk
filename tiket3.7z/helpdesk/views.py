from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Q, Count
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.utils import timezone
from datetime import datetime, timedelta

from .models import Ticket, TicketAttachment, TicketHistory, UserProfile, Category
from .forms import CustomLoginForm, TicketForm, TicketUpdateForm, TicketAttachmentForm, TicketFilterForm


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
        else:
            messages.error(request, 'Username atau password salah.')
    else:
        form = CustomLoginForm()
    
    return render(request, 'helpdesk/login.html', {'form': form})


@login_required
def logout_view(request):
    logout(request)
    messages.success(request, 'Anda telah berhasil logout.')
    return redirect('login')


@login_required
def dashboard(request):
    user_profile = getattr(request.user, 'userprofile', None)
    
    # Get statistics
    if user_profile and user_profile.role == 'admin':
        # Admin dashboard - see all tickets
        total_tickets = Ticket.objects.count()
        open_tickets = Ticket.objects.filter(status='open').count()
        in_progress_tickets = Ticket.objects.filter(status='in_progress').count()
        pending_approval = Ticket.objects.filter(status='pending_approval').count()
        closed_tickets = Ticket.objects.filter(status='closed').count()
        
        # Recent tickets
        recent_tickets = Ticket.objects.all()[:10]
        
        # Tickets by category
        tickets_by_category = Ticket.objects.values('category').annotate(
            count=Count('id')
        ).order_by('-count')
        
        context = {
            'user_role': 'admin',
            'total_tickets': total_tickets,
            'open_tickets': open_tickets,
            'in_progress_tickets': in_progress_tickets,
            'pending_approval': pending_approval,
            'closed_tickets': closed_tickets,
            'recent_tickets': recent_tickets,
            'tickets_by_category': tickets_by_category,
        }
    else:
        # Helpdesk dashboard - see own tickets
        my_tickets = Ticket.objects.filter(created_by=request.user)
        assigned_tickets = Ticket.objects.filter(assigned_to=request.user)
        
        total_my_tickets = my_tickets.count()
        open_my_tickets = my_tickets.filter(status='open').count()
        in_progress_my_tickets = my_tickets.filter(status='in_progress').count()
        closed_my_tickets = my_tickets.filter(status='closed').count()
        
        total_assigned = assigned_tickets.count()
        
        # Recent tickets
        recent_tickets = my_tickets[:10]
        
        context = {
            'user_role': 'helpdesk',
            'total_my_tickets': total_my_tickets,
            'open_my_tickets': open_my_tickets,
            'in_progress_my_tickets': in_progress_my_tickets,
            'closed_my_tickets': closed_my_tickets,
            'total_assigned': total_assigned,
            'recent_tickets': recent_tickets,
        }
    
    return render(request, 'helpdesk/dashboard.html', context)


@login_required
def ticket_list(request):
    user_profile = getattr(request.user, 'userprofile', None)
    
    # Base queryset based on user role
    if user_profile and user_profile.role == 'admin':
        tickets = Ticket.objects.all()
    else:
        tickets = Ticket.objects.filter(
            Q(created_by=request.user) | Q(assigned_to=request.user)
        )
    
    # Apply filters
    filter_form = TicketFilterForm(request.GET)
    if filter_form.is_valid():
        if filter_form.cleaned_data['status']:
            tickets = tickets.filter(status=filter_form.cleaned_data['status'])
        if filter_form.cleaned_data['category']:
            tickets = tickets.filter(category=filter_form.cleaned_data['category'])
        if filter_form.cleaned_data['priority']:
            tickets = tickets.filter(priority=filter_form.cleaned_data['priority'])
        if filter_form.cleaned_data['search']:
            search_term = filter_form.cleaned_data['search']
            tickets = tickets.filter(
                Q(ticket_number__icontains=search_term) |
                Q(title__icontains=search_term) |
                Q(user_name__icontains=search_term)
            )
        if filter_form.cleaned_data['date_from']:
            tickets = tickets.filter(created_at__date__gte=filter_form.cleaned_data['date_from'])
        if filter_form.cleaned_data['date_to']:
            tickets = tickets.filter(created_at__date__lte=filter_form.cleaned_data['date_to'])
    
    # Pagination
    paginator = Paginator(tickets, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'filter_form': filter_form,
        'user_role': user_profile.role if user_profile else 'helpdesk',
    }
    
    return render(request, 'helpdesk/ticket_list.html', context)


@login_required
def ticket_create(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.created_by = request.user
            ticket.save()
            
            # Create history entry
            TicketHistory.objects.create(
                ticket=ticket,
                action='Tiket Dibuat',
                description=f'Tiket {ticket.ticket_number} dibuat oleh {request.user.get_full_name()}',
                created_by=request.user
            )
            
            messages.success(request, f'Tiket {ticket.ticket_number} berhasil dibuat.')
            return redirect('ticket_detail', pk=ticket.pk)
    else:
        form = TicketForm()
    
    return render(request, 'helpdesk/ticket_create.html', {'form': form})


@login_required
def ticket_detail(request, pk):
    user_profile = getattr(request.user, 'userprofile', None)
    
    # Check permissions
    if user_profile and user_profile.role == 'admin':
        ticket = get_object_or_404(Ticket, pk=pk)
    else:
        ticket = get_object_or_404(
            Ticket, 
            Q(pk=pk) & (Q(created_by=request.user) | Q(assigned_to=request.user))
        )
    
    # Get ticket history and attachments
    history = ticket.history.all()
    attachments = ticket.attachments.all()
    
    context = {
        'ticket': ticket,
        'history': history,
        'attachments': attachments,
        'user_role': user_profile.role if user_profile else 'helpdesk',
    }
    
    return render(request, 'helpdesk/ticket_detail.html', context)


@login_required
def ticket_update(request, pk):
    user_profile = getattr(request.user, 'userprofile', None)
    
    # Check permissions
    if user_profile and user_profile.role == 'admin':
        ticket = get_object_or_404(Ticket, pk=pk)
    else:
        ticket = get_object_or_404(
            Ticket, 
            Q(pk=pk) & (Q(created_by=request.user) | Q(assigned_to=request.user))
        )
    
    if request.method == 'POST':
        form = TicketUpdateForm(request.POST, instance=ticket, user=request.user)
        if form.is_valid():
            old_status = ticket.status
            updated_ticket = form.save()
            
            # Create history entry for status change
            if old_status != updated_ticket.status:
                status_display = dict(Ticket.STATUS_CHOICES)[updated_ticket.status]
                TicketHistory.objects.create(
                    ticket=updated_ticket,
                    action='Status Diubah',
                    description=f'Status diubah dari {dict(Ticket.STATUS_CHOICES)[old_status]} ke {status_display}',
                    created_by=request.user
                )
            
            messages.success(request, 'Tiket berhasil diupdate.')
            return redirect('ticket_detail', pk=ticket.pk)
    else:
        form = TicketUpdateForm(instance=ticket, user=request.user)
    
    context = {
        'form': form,
        'ticket': ticket,
        'user_role': user_profile.role if user_profile else 'helpdesk',
    }
    
    return render(request, 'helpdesk/ticket_update.html', context)


@login_required
def ticket_approve(request, pk):
    user_profile = getattr(request.user, 'userprofile', None)
    
    # Only admin can approve tickets
    if not user_profile or user_profile.role != 'admin':
        messages.error(request, 'Anda tidak memiliki izin untuk menyetujui tiket.')
        return redirect('ticket_detail', pk=pk)
    
    ticket = get_object_or_404(Ticket, pk=pk, status='pending_approval')
    
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'approve':
            ticket.status = 'closed'
            ticket.save()
            
            TicketHistory.objects.create(
                ticket=ticket,
                action='Tiket Disetujui',
                description=f'Tiket disetujui dan ditutup oleh {request.user.get_full_name()}',
                created_by=request.user
            )
            
            messages.success(request, f'Tiket {ticket.ticket_number} telah disetujui dan ditutup.')
        elif action == 'reject':
            ticket.status = 'in_progress'
            ticket.save()
            
            TicketHistory.objects.create(
                ticket=ticket,
                action='Persetujuan Ditolak',
                description=f'Persetujuan ditolak oleh {request.user.get_full_name()}, tiket dikembalikan ke status dalam proses',
                created_by=request.user
            )
            
            messages.warning(request, f'Persetujuan tiket {ticket.ticket_number} ditolak.')
        
        return redirect('ticket_detail', pk=pk)
    
    return render(request, 'helpdesk/ticket_approve.html', {'ticket': ticket})


@login_required
def upload_attachment(request, pk):
    user_profile = getattr(request.user, 'userprofile', None)
    
    # Check permissions
    if user_profile and user_profile.role == 'admin':
        ticket = get_object_or_404(Ticket, pk=pk)
    else:
        ticket = get_object_or_404(
            Ticket, 
            Q(pk=pk) & (Q(created_by=request.user) | Q(assigned_to=request.user))
        )
    
    if request.method == 'POST':
        form = TicketAttachmentForm(request.POST, request.FILES)
        if form.is_valid():
            attachment = form.save(commit=False)
            attachment.ticket = ticket
            attachment.uploaded_by = request.user
            attachment.save()
            
            TicketHistory.objects.create(
                ticket=ticket,
                action='File Dilampirkan',
                description=f'File {attachment.filename} dilampirkan oleh {request.user.get_full_name()}',
                created_by=request.user
            )
            
            messages.success(request, 'File berhasil dilampirkan.')
            return redirect('ticket_detail', pk=pk)
    
    return redirect('ticket_detail', pk=pk)


# Master Data Views
@login_required
def master_category_list(request):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    categories = Category.objects.all().order_by('name')
    
    context = {
        'categories': categories,
        'user_role': user_profile.role,
    }
    return render(request, 'helpdesk/master_category.html', context)

@login_required
def master_category_create(request):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        
        if name:
            try:
                Category.objects.create(
                    name=name,
                    description=description,
                    created_by=request.user
                )
                messages.success(request, f'Kategori "{name}" berhasil ditambahkan.')
            except Exception as e:
                messages.error(request, f'Error: {str(e)}')
        else:
            messages.error(request, 'Nama kategori harus diisi.')
    
    return redirect('master_category_list')

@login_required
def master_category_update(request, pk):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        is_active = request.POST.get('is_active') == 'on'
        
        if name:
            try:
                category.name = name
                category.description = description
                category.is_active = is_active
                category.save()
                messages.success(request, f'Kategori "{name}" berhasil diupdate.')
            except Exception as e:
                messages.error(request, f'Error: {str(e)}')
        else:
            messages.error(request, 'Nama kategori harus diisi.')
    
    return redirect('master_category_list')

@login_required
def master_category_delete(request, pk):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    category = get_object_or_404(Category, pk=pk)
    
    # Cek apakah kategori masih digunakan
    if category.ticket_set.exists():
        messages.error(request, f'Kategori "{category.name}" tidak dapat dihapus karena masih digunakan oleh tiket.')
    else:
        category_name = category.name
        category.delete()
        messages.success(request, f'Kategori "{category_name}" berhasil dihapus.')
    
    return redirect('master_category_list')

@login_required
def master_user_list(request):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    users = User.objects.all().order_by('username')
    
    context = {
        'users': users,
        'user_role': user_profile.role,
    }
    return render(request, 'helpdesk/master_user.html', context)

@login_required
def master_user_create(request):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')
        role = request.POST.get('role')
        
        if username and password and role:
            try:
                # Buat user baru
                user = User.objects.create_user(
                    username=username,
                    email=email,
                    first_name=first_name,
                    last_name=last_name,
                    password=password
                )
                
                # Buat profile
                UserProfile.objects.create(
                    user=user,
                    role=role
                )
                
                messages.success(request, f'User "{username}" berhasil ditambahkan.')
            except Exception as e:
                messages.error(request, f'Error: {str(e)}')
        else:
            messages.error(request, 'Username, password, dan role harus diisi.')
    
    return redirect('master_user_list')

@login_required
def master_user_update(request, pk):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    user = get_object_or_404(User, pk=pk)
    
    if request.method == 'POST':
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        is_active = request.POST.get('is_active') == 'on'
        role = request.POST.get('role')
        
        try:
            user.email = email
            user.first_name = first_name
            user.last_name = last_name
            user.is_active = is_active
            user.save()
            
            # Update profile
            profile, created = UserProfile.objects.get_or_create(user=user)
            profile.role = role
            profile.save()
            
            messages.success(request, f'User "{user.username}" berhasil diupdate.')
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')
    
    return redirect('master_user_list')

@login_required
def master_user_delete(request, pk):
    # Hanya admin yang bisa akses
    try:
        user_profile = request.user.userprofile
        if user_profile.role != 'admin':
            messages.error(request, 'Anda tidak memiliki akses ke halaman ini.')
            return redirect('dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    user = get_object_or_404(User, pk=pk)
    
    # Tidak bisa hapus diri sendiri
    if user == request.user:
        messages.error(request, 'Anda tidak dapat menghapus akun Anda sendiri.')
        return redirect('master_user_list')
    
    # Cek apakah user masih memiliki tiket
    if user.ticket_set.exists() or user.assigned_tickets.exists():
        messages.error(request, f'User "{user.username}" tidak dapat dihapus karena masih memiliki tiket terkait.')
    else:
        username = user.username
        user.delete()
        messages.success(request, f'User "{username}" berhasil dihapus.')
    
    return redirect('master_user_list')

@login_required
def reports_view(request):
    try:
        user_profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        messages.error(request, 'Profile pengguna tidak ditemukan.')
        return redirect('dashboard')
    
    # Statistik dasar
    total_tickets = Ticket.objects.count()
    open_tickets = Ticket.objects.filter(status='open').count()
    in_progress_tickets = Ticket.objects.filter(status='in_progress').count()
    closed_tickets = Ticket.objects.filter(status='closed').count()
    
    # Statistik per kategori
    category_stats = Category.objects.annotate(
        ticket_count=Count('ticket')
    ).order_by('-ticket_count')
    
    # Statistik per prioritas
    priority_stats = Ticket.objects.values('priority').annotate(
        count=Count('id')
    ).order_by('-count')
    
    # Statistik per agent (jika admin)
    agent_stats = None
    if user_profile.role == 'admin':
        agent_stats = User.objects.filter(
            userprofile__role='helpdesk'
        ).annotate(
            assigned_count=Count('assigned_tickets'),
            created_count=Count('ticket_set')
        ).order_by('-assigned_count')
    
    context = {
        'user_role': user_profile.role,
        'total_tickets': total_tickets,
        'open_tickets': open_tickets,
        'in_progress_tickets': in_progress_tickets,
        'closed_tickets': closed_tickets,
        'category_stats': category_stats,
        'priority_stats': priority_stats,
        'agent_stats': agent_stats,
    }
    
    return render(request, 'helpdesk/reports.html', context)
