from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import UserProfile, Ticket, TicketAttachment, TicketHistory, Category

# Inline untuk UserProfile
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'
    fields = ('role',)

# Extend UserAdmin untuk menambahkan UserProfile
class CustomUserAdmin(BaseUserAdmin):
    inlines = (UserProfileInline,)
    list_display = ('username', 'email', 'first_name', 'last_name', 'get_role', 'is_active')
    list_filter = ('is_active', 'is_staff', 'userprofile__role')
    
    def get_role(self, obj):
        try:
            return obj.userprofile.get_role_display()
        except UserProfile.DoesNotExist:
            return 'No Profile'
    get_role.short_description = 'Role'
    get_role.admin_order_field = 'userprofile__role'

# Unregister default User admin dan register yang baru
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)

# Admin untuk UserProfile
@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role')
    list_filter = ('role',)
    search_fields = ('user__username', 'user__email', 'user__first_name', 'user__last_name')
    ordering = ('user__username',)

# Inline untuk TicketAttachment
class TicketAttachmentInline(admin.TabularInline):
    model = TicketAttachment
    extra = 0
    readonly_fields = ('uploaded_at', 'filename')
    fields = ('file', 'filename', 'uploaded_by', 'uploaded_at')

# Inline untuk TicketHistory
class TicketHistoryInline(admin.TabularInline):
    model = TicketHistory
    extra = 0
    readonly_fields = ('created_at',)
    fields = ('action', 'description', 'created_by', 'created_at')
    ordering = ('-created_at',)

# Admin untuk Ticket
@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = (
        'ticket_number', 'title', 'category', 'priority', 'status', 
        'created_by', 'assigned_to', 'created_at', 'updated_at'
    )
    list_filter = (
        'status', 'category', 'priority', 'created_at', 'updated_at'
    )
    search_fields = (
        'ticket_number', 'title', 'description', 'user_name', 
        'user_email', 'user_department'
    )
    readonly_fields = (
        'ticket_number', 'created_at', 'updated_at', 'closed_at'
    )
    
    fieldsets = (
        ('Informasi Tiket', {
            'fields': (
                'ticket_number', 'title', 'description', 'category', 'priority'
            )
        }),
        ('Informasi Pelapor', {
            'fields': (
                'user_name', 'user_email', 'user_phone', 
                'user_department', 'user_location'
            )
        }),
        ('Status & Penugasan', {
            'fields': (
                'status', 'created_by', 'assigned_to'
            )
        }),
        ('Penyelesaian', {
            'fields': (
                'resolution', 'notes'
            ),
            'classes': ('collapse',)
        }),
        ('Timestamp', {
            'fields': (
                'created_at', 'updated_at', 'closed_at'
            ),
            'classes': ('collapse',)
        })
    )
    
    inlines = [TicketAttachmentInline, TicketHistoryInline]
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('created_by', 'assigned_to')
    
    def save_model(self, request, obj, form, change):
        if not change:  # Jika objek baru
            obj.created_by = request.user
        super().save_model(request, obj, form, change)
        
        # Buat history entry
        if change:
            TicketHistory.objects.create(
                ticket=obj,
                action='Updated',
                description=f'Tiket diupdate melalui admin panel',
                created_by=request.user
            )

# Admin untuk TicketAttachment
@admin.register(TicketAttachment)
class TicketAttachmentAdmin(admin.ModelAdmin):
    list_display = (
        'filename', 'ticket', 'uploaded_by', 'uploaded_at'
    )
    list_filter = ('uploaded_at',)
    search_fields = (
        'filename', 'ticket__ticket_number', 'ticket__title'
    )
    readonly_fields = ('uploaded_at', 'filename')
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('ticket', 'uploaded_by')

# Admin untuk TicketHistory
@admin.register(TicketHistory)
class TicketHistoryAdmin(admin.ModelAdmin):
    list_display = (
        'ticket', 'action', 'created_by', 'created_at'
    )
    list_filter = ('action', 'created_at')
    search_fields = (
        'ticket__ticket_number', 'ticket__title', 'action', 'description'
    )
    readonly_fields = ('created_at',)
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('ticket', 'created_by')
    
    def has_add_permission(self, request):
        # Mencegah penambahan manual history
        return False
    
    def has_change_permission(self, request, obj=None):
        # Mencegah perubahan manual history
        return False

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'is_active', 'created_at', 'created_by')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'description')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('name',)
    
    fieldsets = (
        (None, {
            'fields': ('name', 'description', 'is_active')
        }),
        ('Informasi Sistem', {
            'fields': ('created_by', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def save_model(self, request, obj, form, change):
        if not change:  # Jika objek baru
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

# Kustomisasi situs admin
admin.site.site_header = "Helpdesk Admin"
admin.site.site_title = "Helpdesk Admin Portal"
admin.site.index_title = "Selamat datang di Helpdesk Administration"
