from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import uuid
import os

# Model untuk Master Kategori
class Category(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name='Nama Kategori')
    description = models.TextField(blank=True, verbose_name='Deskripsi')
    is_active = models.BooleanField(default=True, verbose_name='Aktif')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, verbose_name='Dibuat oleh')
    
    class Meta:
        verbose_name = 'Kategori'
        verbose_name_plural = 'Kategori'
        ordering = ['name']
    
    def __str__(self):
        return self.name


class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('helpdesk', 'Helpdesk Agent'),
        ('admin', 'Admin/Pemimpin'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='helpdesk')
    phone = models.CharField(max_length=15, blank=True)
    
    def __str__(self):
        return f"{self.user.get_full_name()} - {self.get_role_display()}"


class Ticket(models.Model):
    STATUS_CHOICES = [
        ('open', 'Buka'),
        ('in_progress', 'Sedang Ditindaklanjuti'),
        ('pending_approval', 'Menunggu Persetujuan'),
        ('closed', 'Selesai'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Rendah'),
        ('medium', 'Sedang'),
        ('high', 'Tinggi'),
        ('urgent', 'Mendesak'),
    ]
    

    
    # Auto-generated ticket number
    ticket_number = models.CharField(max_length=20, unique=True, editable=False)
    
    # Basic Info
    title = models.CharField(max_length=200, verbose_name='Judul Masalah')
    description = models.TextField(verbose_name='Deskripsi Masalah')
    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        verbose_name='Kategori'
    )
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium', verbose_name='Prioritas')
    
    # User Info
    user_name = models.CharField(max_length=100, verbose_name='Nama Pelapor')
    user_email = models.EmailField(verbose_name='Email Pelapor')
    user_phone = models.CharField(max_length=15, verbose_name='Telepon Pelapor')
    user_department = models.CharField(max_length=100, verbose_name='Unit/Departemen')
    user_location = models.CharField(max_length=100, verbose_name='Lokasi')
    
    # Status & Assignment
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open', verbose_name='Status')
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, 
                                   related_name='assigned_tickets', verbose_name='Ditugaskan Kepada')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_tickets', 
                                  verbose_name='Dibuat Oleh')
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Tanggal Dibuat')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Terakhir Diupdate')
    closed_at = models.DateTimeField(null=True, blank=True, verbose_name='Tanggal Selesai')
    
    # Additional Info
    resolution = models.TextField(blank=True, verbose_name='Solusi/Penyelesaian')
    notes = models.TextField(blank=True, verbose_name='Catatan Internal')
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Tiket'
        verbose_name_plural = 'Tiket'
    
    def save(self, *args, **kwargs):
        if not self.ticket_number:
            # Generate ticket number: TKT-YYYYMMDD-XXX
            today = timezone.now().strftime('%Y%m%d')
            last_ticket = Ticket.objects.filter(
                ticket_number__startswith=f'TKT-{today}'
            ).order_by('ticket_number').last()
            
            if last_ticket:
                last_number = int(last_ticket.ticket_number.split('-')[-1])
                new_number = last_number + 1
            else:
                new_number = 1
            
            self.ticket_number = f'TKT-{today}-{new_number:03d}'
        
        # Set closed_at when status changes to closed
        if self.status == 'closed' and not self.closed_at:
            self.closed_at = timezone.now()
        
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.ticket_number} - {self.title}"


def ticket_attachment_path(instance, filename):
    return f'tickets/{instance.ticket.ticket_number}/{filename}'


class TicketAttachment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='attachments')
    file = models.FileField(upload_to=ticket_attachment_path, verbose_name='File')
    filename = models.CharField(max_length=255, verbose_name='Nama File')
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Diupload Oleh')
    uploaded_at = models.DateTimeField(auto_now_add=True, verbose_name='Tanggal Upload')
    
    def save(self, *args, **kwargs):
        if not self.filename:
            self.filename = os.path.basename(self.file.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.ticket.ticket_number} - {self.filename}"


class TicketHistory(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='history')
    action = models.CharField(max_length=100, verbose_name='Aksi')
    description = models.TextField(verbose_name='Deskripsi')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Dibuat Oleh')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Tanggal')
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Riwayat Tiket'
        verbose_name_plural = 'Riwayat Tiket'
    
    def __str__(self):
        return f"{self.ticket.ticket_number} - {self.action}"
